#!/bin/sh

#repack apk with apktool apktool_2.0.0rc2 from https://bitbucket.org/iBotPeaches/apktool/downloads/apktool_2.0.0rc2.jar
./apktool-rc2 d -f -o out-rc2 app-original.apk
./apktool-rc2 b out-rc2

#sign repacked apk
mv out-rc2/dist/app-original.apk app-repacked.apk
jarsigner -verbose -sigalg SHA1withRSA -digestalg SHA1 -keystore my-release-key.keystore -storepass 12345678 app-repacked.apk alias_name

#decode original apk with apktool1.5.2 from https://android-apktool.googlecode.com/files/apktool1.5.2.tar.bz2
./apktool152 d -f app-original.apk out-152-original

#decode repacked apk with apktool1.5.2 from https://android-apktool.googlecode.com/files/apktool1.5.2.tar.bz2
./apktool152 d -f app-repacked.apk out-152-repacked

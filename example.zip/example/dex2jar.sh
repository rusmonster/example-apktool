#!/bin/sh
#use dex2jar from https://dex2jar.googlecode.com/files/dex2jar-0.0.9.15.zip

./dex2jar-0.0.9.15/d2j-dex2jar.sh --force app-repacked.apk

#error output:
#
# dex2jar app-repacked.apk -> app-repacked-dex2jar.jar
# com.googlecode.dex2jar.DexException: while accept method:[Lcom/example/exampleapktool/MyExample;.crash(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;]
# 	at com.googlecode.dex2jar.reader.DexFileReader.acceptMethod(DexFileReader.java:694)
# 	at com.googlecode.dex2jar.reader.DexFileReader.acceptClass(DexFileReader.java:441)
# 	at com.googlecode.dex2jar.reader.DexFileReader.accept(DexFileReader.java:323)
# 	at com.googlecode.dex2jar.v3.Dex2jar.doTranslate(Dex2jar.java:85)
# 	at com.googlecode.dex2jar.v3.Dex2jar.to(Dex2jar.java:261)
# 	at com.googlecode.dex2jar.v3.Dex2jar.to(Dex2jar.java:252)
# 	at com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:110)
# 	at com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:174)
# 	at com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:34)
# Caused by: com.googlecode.dex2jar.DexException: while accept parameter annotation in method:[Lcom/example/exampleapktool/MyExample;.crash(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;], parameter:[1]
# 	at com.googlecode.dex2jar.reader.DexFileReader.acceptMethod(DexFileReader.java:663)
# 	... 8 more
# Caused by: java.lang.RuntimeException: EOF
# 	at com.googlecode.dex2jar.reader.io.ArrayDataIn.readUByte(ArrayDataIn.java:131)
# 	at com.googlecode.dex2jar.reader.DexAnnotationReader.accept(DexAnnotationReader.java:49)
# 	at com.googlecode.dex2jar.reader.DexFileReader.acceptMethod(DexFileReader.java:660)
# 	... 8 more
